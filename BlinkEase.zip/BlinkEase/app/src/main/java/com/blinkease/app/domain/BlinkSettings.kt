package com.blinkease.app.domain

/**
 * إعدادات التذكير بالرمش.
 *
 * @property intervalSeconds الفاصل بين التذكيرات بالثواني (بين MIN_INTERVAL و MAX_INTERVAL).
 * @property quietStartHour ساعة بداية الهدوء (0..23).
 * @property quietEndHour ساعة نهاية الهدوء (0..23). قد تكون أصغر من البداية (فترة تعبر منتصف الليل).
 * @property pauseUntilMillis وقت انتهاء الإيقاف المؤقت بالميلي ثانية (epoch). 0 = لا يوجد إيقاف.
 */
data class BlinkSettings(
    val enabled: Boolean = false,
    val intervalSeconds: Int = 20,
    val vibrate: Boolean = true,
    val soundEnabled: Boolean = false,
    val overlayEnabled: Boolean = false,
    val quietHoursEnabled: Boolean = false,
    val quietStartHour: Int = 22,
    val quietEndHour: Int = 7,
    val pauseUntilMillis: Long = 0L
)
