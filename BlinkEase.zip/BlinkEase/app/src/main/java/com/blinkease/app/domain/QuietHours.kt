package com.blinkease.app.domain

/**
 * هل الساعة [hour] (0..23) داخل ساعات الهدوء؟
 * - إذا كانت الميزة مطفأة أو البداية = النهاية: لا هدوء.
 * - تدعم الفترة التي تعبر منتصف الليل (مثل 22 → 7).
 */
fun BlinkSettings.isQuietAt(hour: Int): Boolean {
    if (!quietHoursEnabled) return false
    return when {
        quietStartHour == quietEndHour -> false
        quietStartHour < quietEndHour -> hour in quietStartHour until quietEndHour
        else -> hour >= quietStartHour || hour < quietEndHour
    }
}
