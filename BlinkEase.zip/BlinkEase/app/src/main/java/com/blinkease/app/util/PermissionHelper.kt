package com.blinkease.app.util

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LifecycleResumeEffect

object PermissionHelper {

    /** قبل Android 13 لا توجد صلاحية، فتُعتبر ممنوحة. */
    fun hasNotificationPermission(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED

    /** يفتح إعدادات إشعارات التطبيق (للحالة التي لا يظهر فيها حوار الصلاحية). */
    fun openNotificationSettings(context: Context) {
        val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }
}

@Immutable
class NotificationPermissionState(
    val isGranted: Boolean,
    val request: () -> Unit
)

/**
 * حالة صلاحية الإشعارات + دالة لطلبها.
 * - تُحدَّث تلقائيًا عند العودة للتطبيق (مثلاً بعد المنح من الإعدادات).
 * - إذا رُفضت الصلاحية نهائيًا، تفتح الدالة إعدادات الإشعارات بدل الحوار.
 */
@Composable
fun rememberNotificationPermissionState(): NotificationPermissionState {
    val context = LocalContext.current
    var granted by remember {
        mutableStateOf(PermissionHelper.hasNotificationPermission(context))
    }
    var permanentlyDenied by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        granted = isGranted
        if (!isGranted) {
            val activity = context.findActivity()
            permanentlyDenied = activity != null &&
                !ActivityCompat.shouldShowRequestPermissionRationale(
                    activity,
                    Manifest.permission.POST_NOTIFICATIONS
                )
        }
    }

    LifecycleResumeEffect(Unit) {
        granted = PermissionHelper.hasNotificationPermission(context)
        onPauseOrDispose { }
    }

    return remember(granted, permanentlyDenied, launcher) {
        NotificationPermissionState(
            isGranted = granted,
            request = {
                if (permanentlyDenied) {
                    PermissionHelper.openNotificationSettings(context)
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
        )
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
