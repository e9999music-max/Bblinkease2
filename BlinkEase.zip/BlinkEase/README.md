# BlinkEase

تطبيق Android بسيط يذكّرك بالرمش بلطف أثناء استخدام الجوال، للتخفيف من جفاف العين وإجهادها.

## الفكرة

- تختار الفاصل بين التذكيرات (من 10 إلى 120 ثانية).
- تعمل خدمة أمامية خفيفة وتعرض إشعارًا هادئًا (مع اهتزاز اختياري) كل فاصل.
- لا تذكير والشاشة مطفأة، أو أثناء ساعات الهدوء، أو أثناء الإيقاف المؤقت.
- إيقاف مؤقت (15 / 30 / 60 دقيقة) من التطبيق، أو بزر في الإشعار المستمر مع زر استئناف.
- كل الإعدادات تُحفظ على الجهاز فقط. لا إنترنت ولا حسابات ولا جمع بيانات.

## الصلاحيات

| الصلاحية | لماذا |
|---|---|
| `POST_NOTIFICATIONS` | عرض إشعار التذكير (Android 13+، تُطلب من زر داخل التطبيق) |
| `FOREGROUND_SERVICE` | تشغيل الخدمة الأمامية |
| `FOREGROUND_SERVICE_SPECIAL_USE` | نوع الخدمة `specialUse` بقيمة `eye_blink_reminder` |
| `VIBRATE` | الاهتزاز عند التذكير |

لا يستخدم التطبيق صلاحية الإنترنت، ولا AccessibilityService، ولا WorkManager، ولا WakeLock.

## البناء والتشغيل

المتطلبات: Android Studio (Ladybug أو أحدث) مع JDK 17، وجهاز أو محاكي بنظام Android 8.0 (API 26) أو أحدث.

1. افتح مجلد المشروع من Android Studio واترك Gradle Sync يكتمل.
2. اختر `app` ثم اضغط Run.
3. وافق على إذن الإشعارات من الزر داخل التطبيق، ثم فعّل التذكير.

للبناء من سطر الأوامر (بعد إنشاء Gradle wrapper من Android Studio): `./gradlew assembleDebug`

## التقنيات

Kotlin 2.0، Jetpack Compose، Material 3، MVVM، Preferences DataStore، Foreground Service.

## هيكل الحزم

- `data`: SettingsRepository (DataStore)
- `domain`: BlinkSettings وقواعد ساعات الهدوء
- `ui`: الشاشة الرئيسية وMainViewModel والثيم
- `service`: الخدمة الأمامية والإشعارات
- `util`: الثوابت وطلب الصلاحيات والتحكم بالخدمة

## الخصوصية

راجع ملف `PRIVACY_POLICY.md`.
