package com.blinkease.app.ui.theme

import androidx.compose.ui.graphics.Color

// Light
val CalmTeal = Color(0xFF3D7F8C)
val CalmTealContainer = Color(0xFFCDEBF0)
val CalmBlueGrey = Color(0xFF5B7480)
val CalmBlueGreyContainer = Color(0xFFDDE8ED)
val SoftBackground = Color(0xFFF6FAFB)
val SoftSurfaceVariant = Color(0xFFE2ECEF)
val SoftOnSurface = Color(0xFF1B2A2F)
val SoftOnSurfaceVariant = Color(0xFF4A5C62)

// Dark
val CalmTealDark = Color(0xFF9ACFDA)
val CalmTealContainerDark = Color(0xFF1F5560)
val CalmBlueGreyDark = Color(0xFFB3C9D3)
val CalmBlueGreyContainerDark = Color(0xFF3A4D56)
val SoftBackgroundDark = Color(0xFF0F1A1D)
val SoftSurfaceVariantDark = Color(0xFF2B3A3F)
val SoftOnSurfaceDark = Color(0xFFDDE7EA)
val SoftOnSurfaceVariantDark = Color(0xFFB4C4C9)
