#!/usr/bin/env bash
# يبني ملف APK للتجربة (debug) على أي جهاز لينكس فيه إنترنت، مثل GitHub Codespaces.
# التشغيل من داخل مجلد المشروع (الذي فيه settings.gradle.kts):
#   bash build_apk.sh
set -euo pipefail

SDK_DIR="$HOME/android-sdk"
GRADLE_VER="8.9"
CMDTOOLS_URL="https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"

echo "==> Java"
java -version

echo "==> Android SDK"
if [ ! -d "$SDK_DIR/cmdline-tools/latest" ]; then
  mkdir -p "$SDK_DIR/cmdline-tools"
  curl -fL -o /tmp/cmdtools.zip "$CMDTOOLS_URL"
  rm -rf /tmp/cmdtools && unzip -q /tmp/cmdtools.zip -d /tmp/cmdtools
  mv /tmp/cmdtools/cmdline-tools "$SDK_DIR/cmdline-tools/latest"
fi
export ANDROID_HOME="$SDK_DIR"
SDKMANAGER="$SDK_DIR/cmdline-tools/latest/bin/sdkmanager"
yes | "$SDKMANAGER" --licenses > /dev/null || true
"$SDKMANAGER" "platform-tools" "platforms;android-35" "build-tools;35.0.0"
echo "sdk.dir=$SDK_DIR" > local.properties

echo "==> Gradle wrapper"
if [ ! -f gradlew ]; then
  curl -fL -o /tmp/gradle.zip "https://services.gradle.org/distributions/gradle-${GRADLE_VER}-bin.zip"
  mkdir -p "$HOME/gradle"
  unzip -q -o /tmp/gradle.zip -d "$HOME/gradle"
  "$HOME/gradle/gradle-${GRADLE_VER}/bin/gradle" wrapper --gradle-version "${GRADLE_VER}"
fi

echo "==> Build"
./gradlew assembleDebug

APK="$(pwd)/app/build/outputs/apk/debug/app-debug.apk"
echo
echo "تم! ملف APK هنا:"
echo "$APK"
