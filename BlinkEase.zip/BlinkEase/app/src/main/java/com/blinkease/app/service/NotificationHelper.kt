package com.blinkease.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.blinkease.app.MainActivity
import com.blinkease.app.R

/**
 * يبني الإشعارات ويُنشئ القنوات. لا يرسل شيئًا بنفسه؛
 * الخدمة هي من تستدعي startForeground / notify.
 */
class NotificationHelper(context: Context) {

    private val appContext = context.applicationContext

    /** تُستدعى في Application.onCreate. آمنة للتكرار. */
    fun createChannels() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            appContext.getString(R.string.channel_reminders_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = appContext.getString(R.string.channel_reminders_description)
            setSound(null, null)
            enableVibration(false)
            setShowBadge(false)
        }
        appContext.getSystemService(NotificationManager::class.java)
            .createNotificationChannel(channel)
    }

    /** إشعار الخدمة الأمامية الدائم، مع زر إيقاف مؤقت / استئناف. */
    fun buildOngoingNotification(paused: Boolean): Notification {
        val builder = baseBuilder()
            .setContentTitle(appContext.getString(R.string.app_name))
            .setContentText(
                appContext.getString(
                    if (paused) R.string.notif_ongoing_paused else R.string.notif_ongoing_active
                )
            )
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)

        if (paused) {
            builder.addAction(
                0,
                appContext.getString(R.string.notif_action_resume),
                serviceActionIntent(
                    action = BlinkForegroundService.ACTION_RESUME,
                    requestCode = REQUEST_RESUME
                )
            )
        } else {
            builder.addAction(
                0,
                appContext.getString(
                    R.string.notif_action_pause,
                    BlinkForegroundService.DEFAULT_PAUSE_MINUTES
                ),
                serviceActionIntent(
                    action = BlinkForegroundService.ACTION_PAUSE,
                    requestCode = REQUEST_PAUSE,
                    pauseMinutes = BlinkForegroundService.DEFAULT_PAUSE_MINUTES
                )
            )
        }
        return builder.build()
    }

    /** إشعار التذكير الخفيف: صامت، ويختفي تلقائيًا بعد ثوانٍ. */
    fun buildReminderNotification(): Notification =
        baseBuilder()
            .setContentTitle(appContext.getString(R.string.app_name))
            .setContentText(appContext.getString(R.string.notif_reminder_text))
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setTimeoutAfter(REMINDER_TIMEOUT_MS)
            .build()

    private fun baseBuilder(): NotificationCompat.Builder =
        NotificationCompat.Builder(appContext, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(contentIntent())

    private fun contentIntent(): PendingIntent {
        val intent = Intent(appContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            appContext,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    private fun serviceActionIntent(
        action: String,
        requestCode: Int,
        pauseMinutes: Int? = null
    ): PendingIntent {
        val intent = Intent(appContext, BlinkForegroundService::class.java).setAction(action)
        if (pauseMinutes != null) {
            intent.putExtra(BlinkForegroundService.EXTRA_PAUSE_MINUTES, pauseMinutes)
        }
        return PendingIntent.getService(
            appContext,
            requestCode,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    companion object {
        const val CHANNEL_ID = "blink_reminders"
        const val ONGOING_NOTIFICATION_ID = 1001
        const val REMINDER_NOTIFICATION_ID = 1002
        private const val REMINDER_TIMEOUT_MS = 5_000L
        private const val REQUEST_PAUSE = 1
        private const val REQUEST_RESUME = 2
    }
}
