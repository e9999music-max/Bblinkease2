# سياسة الخصوصية — BlinkEase

آخر تحديث: 28 أكتوبر 2026

**BlinkEase لا يجمع أي بيانات ولا يتصل بالإنترنت.**

- لا يطلب التطبيق إذن الإنترنت، ولا يرسل أي معلومات إلى أي جهة.
- لا ينشئ حسابات، ولا يستخدم أدوات تحليل أو إعلانات أو مكتبات تتبّع من جهات خارجية.
- لا يصل إلى جهات الاتصال أو الموقع أو الكاميرا أو الميكروفون أو الملفات.
- إعدادات التذكير (مثل الفاصل الزمني وساعات الهدوء) تُحفظ على جهازك فقط، ولا يمكن لنا الاطلاع عليها.
- صلاحية الإشعارات تُستخدم فقط لعرض تذكير الرمش، وصلاحية الاهتزاز تُستخدم فقط لتنبيهك.
- الخدمة الأمامية تعمل على جهازك فقط لتوقيت التذكيرات، ولا تسجّل نشاطك ولا ما تفعله في الجوال.

عند إلغاء تثبيت التطبيق تُحذف إعداداته من جهازك.

للتواصل: [ضع بريدك الإلكتروني هنا]

---

# Privacy Policy — BlinkEase

Last updated: October 28, 2026

**BlinkEase does not collect any data and does not connect to the internet.**

- The app does not request internet permission and does not send information to anyone.
- It has no accounts, analytics, ads, or third-party tracking libraries.
- It does not access contacts, location, camera, microphone, or files.
- Your reminder settings (interval, quiet hours, etc.) are stored only on your device and are not accessible to us.
- The notification permission is used only to show the blink reminder, and the vibrate permission only to alert you.
- The foreground service runs locally to time reminders. It does not record your activity or what you do on your phone.

Uninstalling the app deletes its settings from your device.

Contact: [your email here]
