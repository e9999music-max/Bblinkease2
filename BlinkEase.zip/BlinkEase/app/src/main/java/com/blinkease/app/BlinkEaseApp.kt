package com.blinkease.app

import android.app.Application
import com.blinkease.app.service.NotificationHelper

class BlinkEaseApp : Application() {
    override fun onCreate() {
        super.onCreate()
        NotificationHelper(this).createChannels()
    }
}
