package com.blinkease.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.blinkease.app.data.SettingsRepository
import com.blinkease.app.domain.BlinkSettings
import com.blinkease.app.util.MAX_INTERVAL
import com.blinkease.app.util.MIN_INTERVAL
import com.blinkease.app.util.ServiceController
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = SettingsRepository.getInstance(application)

    val uiState: StateFlow<BlinkSettings> = repository.settingsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = BlinkSettings()
        )

    init {
        // مزامنة الخدمة مع enabled. نقرأ من الـ repository مباشرة (وليس من uiState)
        // حتى لا نتأثر بالقيمة الابتدائية الافتراضية قبل تحميل DataStore.
        // أول قيمة هنا هي المخزّنة فعلًا، فإذا كانت true والخدمة متوقفة (بعد قتل العملية مثلًا) تُشغَّل.
        viewModelScope.launch {
            repository.settingsFlow
                .map { it.enabled }
                .distinctUntilChanged()
                .collect { enabled ->
                    if (enabled) {
                        ServiceController.start(application)
                    } else {
                        ServiceController.stop(application)
                    }
                }
        }
    }

    fun setEnabled(enabled: Boolean) = update { it.copy(enabled = enabled) }

    fun setInterval(seconds: Int) = update {
        it.copy(intervalSeconds = seconds.coerceIn(MIN_INTERVAL, MAX_INTERVAL))
    }

    fun setVibrate(vibrate: Boolean) = update { it.copy(vibrate = vibrate) }

    fun setSound(enabled: Boolean) = update { it.copy(soundEnabled = enabled) }

    fun setOverlay(enabled: Boolean) = update { it.copy(overlayEnabled = enabled) }

    fun setQuietHours(enabled: Boolean) = update { it.copy(quietHoursEnabled = enabled) }

    fun setQuietStart(hour: Int) = update { it.copy(quietStartHour = hour.coerceIn(0, 23)) }

    fun setQuietEnd(hour: Int) = update { it.copy(quietEndHour = hour.coerceIn(0, 23)) }

    fun pauseFor(minutes: Int) = update {
        it.copy(pauseUntilMillis = System.currentTimeMillis() + minutes * 60_000L)
    }

    fun clearPause() = update { it.copy(pauseUntilMillis = 0L) }

    private fun update(transform: (BlinkSettings) -> BlinkSettings) {
        viewModelScope.launch { repository.update(transform) }
    }
}
