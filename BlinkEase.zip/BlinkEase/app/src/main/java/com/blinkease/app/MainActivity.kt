package com.blinkease.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.blinkease.app.ui.MainScreen
import com.blinkease.app.ui.theme.BlinkEaseTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BlinkEaseTheme {
                MainScreen()
            }
        }
    }
}
