package com.blinkease.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.blinkease.app.domain.BlinkSettings
import com.blinkease.app.util.MAX_INTERVAL
import com.blinkease.app.util.MIN_INTERVAL
import java.io.IOException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map

/**
 * DataStore واحد فقط للتطبيق: الـ delegate على Context يضمن نسخة وحيدة لكل ملف.
 */
private val Context.blinkSettingsDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "blink_settings"
)

class SettingsRepository private constructor(
    private val dataStore: DataStore<Preferences>
) {

    /** يبث الإعدادات الحالية، ويرجع للقيم الافتراضية إذا فشلت القراءة (IOException). */
    val settingsFlow: Flow<BlinkSettings> = dataStore.data
        .catch { e ->
            if (e is IOException) emit(emptyPreferences()) else throw e
        }
        .map { prefs -> prefs.toSettings() }
        .distinctUntilChanged()

    /** تحديث ذري: يقرأ الحالي، يطبّق transform، ينظّف القيم، ثم يكتب. */
    suspend fun update(transform: (BlinkSettings) -> BlinkSettings) {
        dataStore.edit { prefs ->
            val updated = transform(prefs.toSettings()).sanitized()
            prefs.write(updated)
        }
    }

    companion object {
        @Volatile
        private var instance: SettingsRepository? = null

        fun getInstance(context: Context): SettingsRepository =
            instance ?: synchronized(this) {
                instance ?: SettingsRepository(
                    context.applicationContext.blinkSettingsDataStore
                ).also { instance = it }
            }
    }
}

private object Keys {
    val ENABLED = booleanPreferencesKey("enabled")
    val INTERVAL_SECONDS = intPreferencesKey("interval_seconds")
    val VIBRATE = booleanPreferencesKey("vibrate")
    val SOUND_ENABLED = booleanPreferencesKey("sound_enabled")
    val OVERLAY_ENABLED = booleanPreferencesKey("overlay_enabled")
    val QUIET_HOURS_ENABLED = booleanPreferencesKey("quiet_hours_enabled")
    val QUIET_START_HOUR = intPreferencesKey("quiet_start_hour")
    val QUIET_END_HOUR = intPreferencesKey("quiet_end_hour")
    val PAUSE_UNTIL_MILLIS = longPreferencesKey("pause_until_millis")
}

private fun Preferences.toSettings(): BlinkSettings {
    val defaults = BlinkSettings()
    return BlinkSettings(
        enabled = this[Keys.ENABLED] ?: defaults.enabled,
        intervalSeconds = this[Keys.INTERVAL_SECONDS] ?: defaults.intervalSeconds,
        vibrate = this[Keys.VIBRATE] ?: defaults.vibrate,
        soundEnabled = this[Keys.SOUND_ENABLED] ?: defaults.soundEnabled,
        overlayEnabled = this[Keys.OVERLAY_ENABLED] ?: defaults.overlayEnabled,
        quietHoursEnabled = this[Keys.QUIET_HOURS_ENABLED] ?: defaults.quietHoursEnabled,
        quietStartHour = this[Keys.QUIET_START_HOUR] ?: defaults.quietStartHour,
        quietEndHour = this[Keys.QUIET_END_HOUR] ?: defaults.quietEndHour,
        pauseUntilMillis = this[Keys.PAUSE_UNTIL_MILLIS] ?: defaults.pauseUntilMillis
    ).sanitized()
}

private fun MutablePreferences.write(settings: BlinkSettings) {
    this[Keys.ENABLED] = settings.enabled
    this[Keys.INTERVAL_SECONDS] = settings.intervalSeconds
    this[Keys.VIBRATE] = settings.vibrate
    this[Keys.SOUND_ENABLED] = settings.soundEnabled
    this[Keys.OVERLAY_ENABLED] = settings.overlayEnabled
    this[Keys.QUIET_HOURS_ENABLED] = settings.quietHoursEnabled
    this[Keys.QUIET_START_HOUR] = settings.quietStartHour
    this[Keys.QUIET_END_HOUR] = settings.quietEndHour
    this[Keys.PAUSE_UNTIL_MILLIS] = settings.pauseUntilMillis
}

/** يحصر القيم في نطاقاتها الصحيحة سواء عند القراءة أو الكتابة. */
private fun BlinkSettings.sanitized(): BlinkSettings = copy(
    intervalSeconds = intervalSeconds.coerceIn(MIN_INTERVAL, MAX_INTERVAL),
    quietStartHour = quietStartHour.coerceIn(0, 23),
    quietEndHour = quietEndHour.coerceIn(0, 23),
    pauseUntilMillis = pauseUntilMillis.coerceAtLeast(0L)
)
