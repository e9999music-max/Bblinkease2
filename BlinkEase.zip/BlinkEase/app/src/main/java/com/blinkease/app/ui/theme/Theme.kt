package com.blinkease.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColors = lightColorScheme(
    primary = CalmTeal,
    primaryContainer = CalmTealContainer,
    secondary = CalmBlueGrey,
    secondaryContainer = CalmBlueGreyContainer,
    background = SoftBackground,
    surface = SoftBackground,
    surfaceVariant = SoftSurfaceVariant,
    onBackground = SoftOnSurface,
    onSurface = SoftOnSurface,
    onSurfaceVariant = SoftOnSurfaceVariant
)

private val DarkColors = darkColorScheme(
    primary = CalmTealDark,
    primaryContainer = CalmTealContainerDark,
    secondary = CalmBlueGreyDark,
    secondaryContainer = CalmBlueGreyContainerDark,
    background = SoftBackgroundDark,
    surface = SoftBackgroundDark,
    surfaceVariant = SoftSurfaceVariantDark,
    onBackground = SoftOnSurfaceDark,
    onSurface = SoftOnSurfaceDark,
    onSurfaceVariant = SoftOnSurfaceVariantDark
)

@Composable
fun BlinkEaseTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = Typography,
        content = content
    )
}
