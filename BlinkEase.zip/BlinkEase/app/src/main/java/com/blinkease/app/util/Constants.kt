package com.blinkease.app.util

/** أقل فاصل بين التذكيرات (بالثواني). */
const val MIN_INTERVAL = 10

/** أكبر فاصل بين التذكيرات (بالثواني). */
const val MAX_INTERVAL = 120
