package com.blinkease.app.ui

import android.content.res.Configuration
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.blinkease.app.R
import com.blinkease.app.domain.BlinkSettings
import com.blinkease.app.ui.theme.BlinkEaseTheme
import com.blinkease.app.util.MAX_INTERVAL
import com.blinkease.app.util.MIN_INTERVAL
import com.blinkease.app.util.rememberNotificationPermissionState
import java.text.DateFormat
import java.util.Date
import kotlin.math.roundToInt

private val PAUSE_OPTIONS_MINUTES = listOf(15, 30, 60)

/** كل ردود أفعال الواجهة في مكان واحد، لتسهيل الـ previews. */
@Immutable
data class MainActions(
    val onEnabledChange: (Boolean) -> Unit = {},
    val onIntervalChange: (Int) -> Unit = {},
    val onVibrateChange: (Boolean) -> Unit = {},
    val onSoundChange: (Boolean) -> Unit = {},
    val onQuietHoursChange: (Boolean) -> Unit = {},
    val onQuietStartChange: (Int) -> Unit = {},
    val onQuietEndChange: (Int) -> Unit = {},
    val onPause: (Int) -> Unit = {},
    val onClearPause: () -> Unit = {}
)

@Composable
fun MainScreen(viewModel: MainViewModel = viewModel()) {
    val settings by viewModel.uiState.collectAsStateWithLifecycle()
    val notificationPermission = rememberNotificationPermissionState()
    val actions = remember(viewModel) {
        MainActions(
            onEnabledChange = viewModel::setEnabled,
            onIntervalChange = viewModel::setInterval,
            onVibrateChange = viewModel::setVibrate,
            onSoundChange = viewModel::setSound,
            onQuietHoursChange = viewModel::setQuietHours,
            onQuietStartChange = viewModel::setQuietStart,
            onQuietEndChange = viewModel::setQuietEnd,
            onPause = viewModel::pauseFor,
            onClearPause = viewModel::clearPause
        )
    }
    MainContent(
        settings = settings,
        actions = actions,
        notificationsGranted = notificationPermission.isGranted,
        onRequestNotifications = notificationPermission.request
    )
}

@Composable
private fun MainContent(
    settings: BlinkSettings,
    actions: MainActions,
    notificationsGranted: Boolean = true,
    onRequestNotifications: () -> Unit = {}
) {
    Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Header()
            if (!notificationsGranted) {
                NotificationPermissionCard(onRequestNotifications)
            }
            EnableCard(settings.enabled, actions.onEnabledChange)
            IntervalCard(settings.intervalSeconds, actions.onIntervalChange)
            AlertsCard(
                vibrate = settings.vibrate,
                sound = settings.soundEnabled,
                onVibrateChange = actions.onVibrateChange,
                onSoundChange = actions.onSoundChange
            )
            PauseCard(settings.pauseUntilMillis, actions.onPause, actions.onClearPause)
            QuietHoursCard(
                enabled = settings.quietHoursEnabled,
                startHour = settings.quietStartHour,
                endHour = settings.quietEndHour,
                onEnabledChange = actions.onQuietHoursChange,
                onStartChange = actions.onQuietStartChange,
                onEndChange = actions.onQuietEndChange
            )
        }
    }
}

@Composable
private fun Header() {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = stringResource(R.string.app_name),
            style = MaterialTheme.typography.displaySmall,
            color = MaterialTheme.colorScheme.primary,
            textAlign = TextAlign.Center
        )
        Text(
            text = stringResource(R.string.main_subtitle),
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
private fun NotificationPermissionCard(onRequest: () -> Unit) {
    SectionCard {
        Text(
            text = stringResource(R.string.notif_permission_message),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Button(
            onClick = onRequest,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(stringResource(R.string.notif_permission_button))
        }
    }
}

@Composable
private fun SectionCard(
    title: String? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (title != null) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            content()
        }
    }
}

@Composable
private fun EnableCard(enabled: Boolean, onEnabledChange: (Boolean) -> Unit) {
    SectionCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.reminder_title),
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = stringResource(
                        if (enabled) R.string.reminder_on else R.string.reminder_off
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(checked = enabled, onCheckedChange = onEnabledChange)
        }
    }
}

@Composable
private fun IntervalCard(intervalSeconds: Int, onIntervalChange: (Int) -> Unit) {
    // قيمة محلية أثناء السحب، ونحفظ في DataStore عند رفع الإصبع فقط.
    var sliderValue by remember(intervalSeconds) {
        mutableFloatStateOf(intervalSeconds.toFloat())
    }

    SectionCard(title = stringResource(R.string.interval_title)) {
        Text(
            text = stringResource(R.string.interval_value, sliderValue.roundToInt()),
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )
        Slider(
            value = sliderValue,
            onValueChange = { sliderValue = it },
            onValueChangeFinished = { onIntervalChange(sliderValue.roundToInt()) },
            valueRange = MIN_INTERVAL.toFloat()..MAX_INTERVAL.toFloat()
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = MIN_INTERVAL.toString(),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = MAX_INTERVAL.toString(),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun AlertsCard(
    vibrate: Boolean,
    sound: Boolean,
    onVibrateChange: (Boolean) -> Unit,
    onSoundChange: (Boolean) -> Unit
) {
    SectionCard(title = stringResource(R.string.alerts_title)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            LabeledSwitch(
                label = stringResource(R.string.vibrate_label),
                checked = vibrate,
                onCheckedChange = onVibrateChange,
                modifier = Modifier.weight(1f)
            )
            LabeledSwitch(
                label = stringResource(R.string.sound_label),
                checked = sound,
                onCheckedChange = onSoundChange,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun LabeledSwitch(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.weight(1f)
        )
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun PauseCard(
    pauseUntilMillis: Long,
    onPause: (Int) -> Unit,
    onClearPause: () -> Unit
) {
    val isPaused = remember(pauseUntilMillis) {
        pauseUntilMillis > System.currentTimeMillis()
    }

    SectionCard(title = stringResource(R.string.pause_title)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            PAUSE_OPTIONS_MINUTES.forEach { minutes ->
                FilledTonalButton(
                    onClick = { onPause(minutes) },
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = stringResource(R.string.pause_minutes, minutes),
                        maxLines = 1
                    )
                }
            }
        }
        if (isPaused) {
            val untilText = remember(pauseUntilMillis) {
                DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(pauseUntilMillis))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = stringResource(R.string.pause_until, untilText),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = onClearPause) {
                    Text(stringResource(R.string.pause_cancel))
                }
            }
        }
    }
}

@Composable
private fun QuietHoursCard(
    enabled: Boolean,
    startHour: Int,
    endHour: Int,
    onEnabledChange: (Boolean) -> Unit,
    onStartChange: (Int) -> Unit,
    onEndChange: (Int) -> Unit
) {
    SectionCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = stringResource(R.string.quiet_title),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.weight(1f)
            )
            Switch(checked = enabled, onCheckedChange = onEnabledChange)
        }
        HourStepper(
            label = stringResource(R.string.quiet_from),
            hour = startHour,
            enabled = enabled,
            onHourChange = onStartChange
        )
        HourStepper(
            label = stringResource(R.string.quiet_to),
            hour = endHour,
            enabled = enabled,
            onHourChange = onEndChange
        )
    }
}

@Composable
private fun HourStepper(
    label: String,
    hour: Int,
    enabled: Boolean,
    onHourChange: (Int) -> Unit
) {
    val textColor = if (enabled) {
        MaterialTheme.colorScheme.onSurface
    } else {
        MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
    }

    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            color = textColor,
            modifier = Modifier.weight(1f)
        )
        FilledTonalIconButton(
            onClick = { onHourChange((hour + 23) % 24) },
            enabled = enabled
        ) {
            Text("−")
        }
        Text(
            text = stringResource(R.string.hour_format, hour),
            style = MaterialTheme.typography.titleMedium,
            color = textColor,
            textAlign = TextAlign.Center,
            modifier = Modifier.widthIn(min = 72.dp)
        )
        FilledTonalIconButton(
            onClick = { onHourChange((hour + 1) % 24) },
            enabled = enabled
        ) {
            Text("+")
        }
    }
}

@Preview(showBackground = true, heightDp = 1000)
@Composable
private fun MainContentDefaultPreview() {
    BlinkEaseTheme {
        MainContent(
            settings = BlinkSettings(),
            actions = MainActions(),
            notificationsGranted = false
        )
    }
}

@Preview(showBackground = true, heightDp = 1000)
@Composable
private fun MainContentActivePreview() {
    BlinkEaseTheme {
        MainContent(
            settings = BlinkSettings(
                enabled = true,
                intervalSeconds = 45,
                soundEnabled = true,
                quietHoursEnabled = true,
                pauseUntilMillis = System.currentTimeMillis() + 30 * 60_000L
            ),
            actions = MainActions()
        )
    }
}

@Preview(
    showBackground = true,
    heightDp = 1000,
    uiMode = Configuration.UI_MODE_NIGHT_YES
)
@Composable
private fun MainContentDarkPreview() {
    BlinkEaseTheme {
        MainContent(
            settings = BlinkSettings(enabled = true, quietHoursEnabled = true),
            actions = MainActions()
        )
    }
}
