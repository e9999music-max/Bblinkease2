package com.blinkease.app.util

import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.content.ContextCompat
import com.blinkease.app.service.BlinkForegroundService

object ServiceController {

    private const val TAG = "ServiceController"

    /** يشغّل الخدمة الأمامية. يجب استدعاؤها والتطبيق ظاهر للمستخدم. */
    fun start(context: Context) {
        val intent = Intent(context, BlinkForegroundService::class.java)
            .setAction(BlinkForegroundService.ACTION_START)
        try {
            ContextCompat.startForegroundService(context, intent)
        } catch (e: IllegalStateException) {
            // مثل ForegroundServiceStartNotAllowedException إذا كان التطبيق في الخلفية.
            Log.w(TAG, "Could not start foreground service", e)
        }
    }

    /** يوقف الخدمة (لا يفعل شيئًا إذا لم تكن تعمل). */
    fun stop(context: Context) {
        context.stopService(Intent(context, BlinkForegroundService::class.java))
    }
}
