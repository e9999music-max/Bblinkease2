package com.blinkease.app.ui.theme

import androidx.compose.material3.Typography

// الافتراضي من Material3 كافٍ في هذه المرحلة.
val Typography = Typography()
