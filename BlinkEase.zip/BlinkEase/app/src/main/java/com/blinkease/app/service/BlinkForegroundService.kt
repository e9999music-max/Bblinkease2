package com.blinkease.app.service

import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import androidx.core.app.ServiceCompat
import com.blinkease.app.data.SettingsRepository
import com.blinkease.app.domain.BlinkSettings
import com.blinkease.app.domain.isQuietAt
import java.time.LocalTime
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * خدمة أمامية عادية (ليست LifecycleService).
 * مصدر الحقيقة الوحيد هو DataStore: أي تغيير في الإعدادات (من الواجهة أو من أزرار الإشعار)
 * يمر عبر settingsFlow فتعيد الحلقة بناء نفسها.
 * لا WorkManager، لا AccessibilityService، لا WakeLock.
 */
class BlinkForegroundService : Service() {

    private lateinit var repository: SettingsRepository
    private lateinit var notificationHelper: NotificationHelper
    private lateinit var notificationManager: NotificationManager
    private lateinit var powerManager: PowerManager

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var loopJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        repository = SettingsRepository.getInstance(this)
        notificationHelper = NotificationHelper(this)
        notificationManager = getSystemService(NotificationManager::class.java)
        powerManager = getSystemService(PowerManager::class.java)

        ServiceCompat.startForeground(
            this,
            NotificationHelper.ONGOING_NOTIFICATION_ID,
            notificationHelper.buildOngoingNotification(paused = false),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        )

        loopJob = scope.launch {
            repository.settingsFlow.collectLatest { settings ->
                runReminderLoop(settings)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PAUSE -> pauseFor(
                intent.getIntExtra(EXTRA_PAUSE_MINUTES, DEFAULT_PAUSE_MINUTES)
            )
            ACTION_RESUME -> resume()
            // ACTION_START أو null (إعادة تشغيل من النظام): الخدمة أمامية أصلًا.
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        loopJob?.cancel()
        scope.cancel()
        notificationManager.cancel(NotificationHelper.REMINDER_NOTIFICATION_ID)
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    // ---------------------------------------------------------------- الحلقة

    /**
     * تُلغى تلقائيًا عند وصول إعدادات جديدة (collectLatest) فيُعاد ضبط المؤقت.
     */
    private suspend fun runReminderLoop(settings: BlinkSettings) {
        coroutineScope {
            refreshOngoingNotification(settings)

            // تحديث نص الإشعار المستمر لحظة انتهاء الإيقاف المؤقت.
            val remainingPauseMs = settings.pauseUntilMillis - System.currentTimeMillis()
            if (remainingPauseMs > 0) {
                launch {
                    delay(remainingPauseMs)
                    refreshOngoingNotification(settings)
                }
            }

            while (isActive) {
                delay(settings.intervalSeconds * 1000L)
                val reason = skipReason(settings)
                if (reason == null) {
                    remind(settings)
                } else {
                    Log.d(TAG, "tick skipped: $reason")
                }
            }
        }
    }

    /** null = يجب التذكير الآن، وإلا سبب التخطي. */
    private fun skipReason(settings: BlinkSettings): String? = when {
        !settings.enabled -> "disabled"
        !powerManager.isInteractive -> "screen off"
        settings.isQuietAt(LocalTime.now().hour) -> "quiet hours"
        settings.pauseUntilMillis > System.currentTimeMillis() -> "paused"
        else -> null
    }

    private fun remind(settings: BlinkSettings) {
        Log.d(TAG, "remind (vibrate=${settings.vibrate})")
        notificationManager.notify(
            NotificationHelper.REMINDER_NOTIFICATION_ID,
            notificationHelper.buildReminderNotification()
        )
        if (settings.vibrate) vibrate()
    }

    private fun vibrate() {
        val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Vibrator::class.java)
        }
        vibrator?.vibrate(
            VibrationEffect.createOneShot(VIBRATION_MS, VibrationEffect.DEFAULT_AMPLITUDE)
        )
    }

    private fun refreshOngoingNotification(settings: BlinkSettings) {
        val paused = settings.pauseUntilMillis > System.currentTimeMillis()
        notificationManager.notify(
            NotificationHelper.ONGOING_NOTIFICATION_ID,
            notificationHelper.buildOngoingNotification(paused)
        )
    }

    // ---------------------------------------------------------------- إيقاف مؤقت

    private fun pauseFor(minutes: Int) {
        scope.launch {
            repository.update {
                it.copy(pauseUntilMillis = System.currentTimeMillis() + minutes * 60_000L)
            }
        }
    }

    private fun resume() {
        scope.launch { repository.update { it.copy(pauseUntilMillis = 0L) } }
    }

    companion object {
        private const val TAG = "BlinkService"
        private const val VIBRATION_MS = 150L

        const val ACTION_START = "com.blinkease.app.action.START"
        const val ACTION_PAUSE = "com.blinkease.app.action.PAUSE"
        const val ACTION_RESUME = "com.blinkease.app.action.RESUME"
        const val EXTRA_PAUSE_MINUTES = "extra_pause_minutes"
        const val DEFAULT_PAUSE_MINUTES = 15
    }
}
